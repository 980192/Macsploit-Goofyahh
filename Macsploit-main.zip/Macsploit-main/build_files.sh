cmake -S . -B ./cmake-build-debug
cd cmake-build-debug
ninja
