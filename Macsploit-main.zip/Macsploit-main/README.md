# Macsploit's source

Macsploit is a shitty, pasted, skidded executor that is somehow $10.

This source was leaked by [bunni.lol](https://discord.gg/bunnilol)'s owner on 6/8/2024.
